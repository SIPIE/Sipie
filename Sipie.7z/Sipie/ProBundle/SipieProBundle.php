<?php

namespace Sipie\ProBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SipieProBundle extends Bundle
{
}
