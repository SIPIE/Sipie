<?php

namespace Sipie\ProBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class FichaType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('usuario', 'entity', array('class' => 'SipieProBundle:Usuario', 'property' => 'rut', 'required' => true))
            ->add('paciente', 'entity', array('class' => 'SipieProBundle:Paciente', 'property' => 'rut', 'required' => true))
	        ->add('fechaintervencion', 'date', array(
                'widget' => 'single_text',
                'required' => true,
				'format'=>'MM-dd-yyyy',
                'label' => 'Fecha de intervención',
                'attr' => array(
                    'class' => 'form-group input-inline datetimepicker',
                    'data-provide' => 'datepicker',
                    'data-format' => 'mm-dd-yyyy',
                ),
            ))
            ->add('actividad','text', array('label' => 'Actividad'))
            ->add('objetivo','text', array('label' => 'Objetivo'))
            ->add('observacion','textarea', array('label' => 'Observación','attr' => array(
                    'rows' => '5',
                ),))
        ;
    }
    
    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'Sipie\ProBundle\Entity\Ficha'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'sipie_probundle_ficha';
    }
}
