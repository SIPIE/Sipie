<?php
namespace Sipie\ProBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * Ficha
 *
 * @ORM\Table()
 * @ORM\Entity
 */
 
class Ficha
{
    /**
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;
    /**
     * @ORM\ManyToOne(targetEntity="Usuario")
     * @ORM\JoinColumn(name="usuario", referencedColumnName="id")
     */
    private $usuario;

    /**
     * @ORM\ManyToOne(targetEntity="Paciente")
     * @ORM\JoinColumn(name="paciente", referencedColumnName="id")
     */
    private $paciente;

    /**
     * @var string
     *
     * @ORM\Column(name="fechaintervencion", type="date", length=6)
     */
    private $fechaintervencion;

    /**
     * @var string
     *
     * @ORM\Column(name="objetivo", type="string", length=60)
     */
    private $objetivo;

    /**
     * @var string
     *
     * @ORM\Column(name="actividad", type="string", length=255)
     */
    private $actividad;

    /**
     * @var string
     *
     * @ORM\Column(name="observacion", type="string", length=255)
     */
    private $observacion;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set usuario
     *
     * @param \Sipie\ProBundle\Entity\Usuario $usuario
     *
     * @return Ficha
     */
    public function setUsuario(\Sipie\ProBundle\Entity\Usuario $usuario = null)
    {
        $this->usuario = $usuario;

        return $this;
    }

    /**
     * Get usuario
     *
     * @return \Sipie\ProBundle\Entity\Usuario
     */
    public function getUsuario()
    {
        return $this->usuario;
    }

    /**
     * Set paciente
     *
     * @param \Sipie\ProBundle\Entity\Paciente $paciente
     *
     * @return Ficha
     */
    public function setPaciente(\Sipie\ProBundle\Entity\Paciente $paciente = null)
    {
        $this->paciente = $paciente;

        return $this;
    }

    /**
     * Get paciente
     *
     * @return \Sipie\ProBundle\Entity\Paciente
     */
    public function getPaciente()
    {
        return $this->paciente;
    }

    /**
     * Set fechaintervencion
     *
     * @param \DateTime $fechaintervencion
     *
     * @return Ficha
     */
    public function setFechaintervencion($fechaintervencion)
    {
        $this->fechaintervencion = $fechaintervencion;

        return $this;
    }

    /**
     * Get fechaintervencion
     *
     * @return \DateTime
     */
    public function getFechaintervencion()
    {
        return $this->fechaintervencion;
    }

    /**
     * Set objetivo
     *
     * @param string $objetivo
     *
     * @return Ficha
     */
    public function setObjetivo($objetivo)
    {
        $this->objetivo = $objetivo;

        return $this;
    }

    /**
     * Get objetivo
     *
     * @return string
     */
    public function getObjetivo()
    {
        return $this->objetivo;
    }

    /**
     * Set actividad
     *
     * @param string $actividad
     *
     * @return Ficha
     */
    public function setActividad($actividad)
    {
        $this->actividad = $actividad;

        return $this;
    }

    /**
     * Get actividad
     *
     * @return string
     */
    public function getActividad()
    {
        return $this->actividad;
    }

    /**
     * Set observacion
     *
     * @param string $observacion
     *
     * @return Ficha
     */
    public function setObservacion($observacion)
    {
        $this->observacion = $observacion;

        return $this;
    }

    /**
     * Get observacion
     *
     * @return string
     */
    public function getObservacion()
    {
        return $this->observacion;
    }
}
